#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure for menu items
struct MenuItem {
    int id;
    char name[50];
    float price;
    int stock;
};

// Structure for customer orders
struct Order {
    int orderId;
    struct MenuItem item;
    int quantity;
    float total;
};

// Admin login credentials
#define USERNAME "admin"
#define PASSWORD "password"

// Function to print a header with decoration
void printHeader(const char *header) {
    printf("=====================================\n");
    printf("           %s\n", header);
    printf("=====================================\n");
}

// Function to display the menu
void displayMenu(struct MenuItem menu[], int size) {
    printHeader("Cafe Menu");
    for (int i = 0; i < size; i++) {
        printf("%d. %-20s $%.2f (Stock: %d)\n", menu[i].id, menu[i].name, menu[i].price, menu[i].stock);
    }
    printf("=====================================\n");
}

// Function to handle admin login
int adminLogin() {
    char username[50], password[50];
    printf("Enter Admin Username: ");
    scanf("%s", username);
    printf("Enter Admin Password: ");
    scanf("%s", password);

    if (strcmp(username, USERNAME) == 0 && strcmp(password, PASSWORD) == 0) {
        printf("Login Successful!\n");
        return 1;
    } else {
        printf("Invalid credentials. Try again.\n");
        return 0;
    }
}

// Function to update menu items
void updateMenu(struct MenuItem menu[], int *size) {
    int choice;
    printHeader("Update Menu");

    printf("1. Add Item\n2. Remove Item\n3. Change Price\nEnter your choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("Enter Item Name: ");
        getchar();  // To consume newline
        fgets(menu[*size].name, 50, stdin);
        menu[*size].name[strcspn(menu[*size].name, "\n")] = '\0';  // Remove newline character
        printf("Enter Item Price: ");
        scanf("%f", &menu[*size].price);
        printf("Enter Item Stock: ");
        scanf("%d", &menu[*size].stock);
        menu[*size].id = *size + 1;
        (*size)++;
    } else if (choice == 2) {
        int removeId;
        printf("Enter Item ID to Remove: ");
        scanf("%d", &removeId);
        for (int i = removeId - 1; i < *size - 1; i++) {
            menu[i] = menu[i + 1];
        }
        (*size)--;
    } else if (choice == 3) {
        int id;
        printf("Enter Item ID to Change Price: ");
        scanf("%d", &id);
        printf("Enter New Price: ");
        scanf("%f", &menu[id - 1].price);
    }
}

// Function to take orders
void takeOrder(struct MenuItem menu[], int size, struct Order *order) {
    int itemId, quantity;
    printHeader("Take Order");

    printf("Enter Item ID: ");
    scanf("%d", &itemId);
    if (itemId > size || itemId <= 0) {
        printf("Invalid Item ID!\n");
        return;
    }
    printf("Enter Quantity: ");
    scanf("%d", &quantity);
    if (menu[itemId - 1].stock < quantity) {
        printf("Insufficient stock!\n");
        return;
    }
    menu[itemId - 1].stock -= quantity;
    order->orderId = rand() % 1000;
    order->item = menu[itemId - 1];
    order->quantity = quantity;
    order->total = order->item.price * quantity;
    printf("Order ID: %d\n", order->orderId);
    printf("Total Bill: $%.2f\n", order->total);
}

int main() {
    struct MenuItem menu[10] = {
        {1, "Coffee", 5.0, 10},
        {2, "Tea", 3.0, 15},
        {3, "Sandwich", 8.0, 20}
    };
    int menuSize = 3;
    struct Order order;

    int choice;
    if (adminLogin()) {
        do {
            printHeader("Cafe Management System");
            printf("1. Display Menu\n2. Update Menu\n3. Take Order\n4. Exit\nEnter your choice: ");
            scanf("%d", &choice);

            switch (choice) {
                case 1:
                    displayMenu(menu, menuSize);
                    break;
                case 2:
                    updateMenu(menu, &menuSize);
                    break;
                case 3:
                    takeOrder(menu, menuSize, &order);
                    break;
                case 4:
                    printf("Exiting Cafe Management System.\n");
                    break;
                default:
                    printf("Invalid choice, please try again.\n");
            }
        } while (choice != 4);
    }

    return 0;
}
